let active = false;
let ytTabs = new Set();
function updateActive() {
  const wasActive = active;
  active = ytTabs.size > 0;
  if (active && !wasActive) {
    browser.runtime.sendNativeMessage('mpris_helper', {action: 'start'});
  } else if (!active && wasActive) {
    browser.runtime.sendNativeMessage('mpris_helper', {action: 'stop'});
  }
}
function checkTab(tab) {
  if (!tab?.url) return;
  const id = tab.id;
  const isYt = !!tab.url.match(/youtube.com/);
  const had = ytTabs.has(id);
  if (isYt && !had) ytTabs.add(id);
  else if (!isYt && had) ytTabs.delete(id);
  updateActive();
}
// on tab switch / window focus
function checkActive() {
  browser.tabs.query({active: true, lastFocusedWindow: true}, ([tab]) => checkTab(tab));
}
// initial + updates
browser.tabs.query({}, tabs => tabs.forEach(checkTab));
browser.tabs.onActivated.addListener(checkActive);
browser.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.url || change.status === 'complete') checkTab(tab);
});
browser.tabs.onRemoved.addListener(id => {
  if (ytTabs.has(id)) { ytTabs.delete(id); updateActive(); }
});
browser.windows.onFocusChanged.addListener(checkActive);

browser.runtime.onSuspend.addListener(() => {
  browser.runtime.sendNativeMessage('mpris_helper', {action: 'stop'});
});
